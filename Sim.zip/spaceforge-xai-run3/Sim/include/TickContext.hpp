#pragma once

struct TickContext {
    int tick_index;
    double time;
    double dt;   // tick step size
};
